'use strict';
/*
    Endpoint URL: https://api.github.com/search/repositories?q={query}
*/

angular.module('PeopleOnGitHubApp', []);
var myApp = angular.module('PeopleOnGitHubApp');

myApp.controller('homeController', ['$scope', '$http',
        function ($scope, $http) {

    $scope.status;
    $scope.searchStr = "";
    $scope.results = [];
	
	function getRepositories(){
		$http.get("https://api.github.com/search/repositories?q="+$scope.searchStr)
               .success(function (data) {
				  localStorage[$scope.searchStr] = JSON.stringify(data.items);
				    console.log( localStorage[$scope.searchStr]);
                  $scope.results = data.items;
                  console.log($scope.results);
               })
               .error(function (error) {
                  $scope.status = error.message; 
               });
	}
    $scope.showResutls = function() {		
			if (typeof(Storage) !== "undefined") { 
				if (localStorage && localStorage[$scope.searchStr]) {
				$scope.results =  JSON.parse(localStorage[$scope.searchStr]);									
				} else {
				getRepositories()
				}
			}			
			else{
				getRepositories();
			}         
    }
	$scope.showDetails = function(item){
		 $http.get(item.owner.followers_url)
               .success(function (data) {                  
				   var followers =[];
                  angular.forEach(data, function(obj, idx){
					  followers.push(obj.login);
				  });
				  alert("Language: "+item.language+"\n\nfollowers: "+followers.join()+"\n\nUrl: "+item.url+"\n\nDescription: " + item.description);
               })
               .error(function (error) {
                  $scope.status = error.message; 
               });
		
	}
    
}]);